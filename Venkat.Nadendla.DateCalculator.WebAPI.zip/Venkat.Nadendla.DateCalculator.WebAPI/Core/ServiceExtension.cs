﻿namespace Core
{
    public class ServiceExtension
    {

    }
}