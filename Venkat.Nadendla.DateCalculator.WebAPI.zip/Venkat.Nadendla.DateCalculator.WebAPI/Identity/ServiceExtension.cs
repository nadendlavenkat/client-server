﻿namespace Identity
{
    public class ServiceExtension
    {

    }
}