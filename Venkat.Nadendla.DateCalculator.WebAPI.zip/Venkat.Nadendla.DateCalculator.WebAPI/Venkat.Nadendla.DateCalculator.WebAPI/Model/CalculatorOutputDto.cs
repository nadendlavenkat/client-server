﻿namespace Venkat.Nadendla.DateCalculator.WebAPI.Model
{
    public class CalculatorOutputDto
    {
        public string fromDate { get; set; }
        public string endDate { get; set; }
        public long numberOfDays { get; set; }
    }
}
