﻿namespace Venkat.Nadendla.DateCalculator.WebAPI.Model
{
    public class CalculatorInputDto
    {
        public string fromDate { get; set; }
        public string endDate { get; set; }
    }
}
