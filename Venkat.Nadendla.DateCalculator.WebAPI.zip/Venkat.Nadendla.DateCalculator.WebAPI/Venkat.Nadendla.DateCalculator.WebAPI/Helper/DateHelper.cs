﻿namespace Venkat.Nadendla.DateCalculator.WebAPI.Helper
{
    public class DateHelper
    {
        /// <summary>
        /// splitting the date by using string type date format dd/mm/yyyy.
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static long GetTotalDays(string dt)
        {
            var split = dt.Split('/');
            return GetDays(int.Parse(split[2]), int.Parse(split[1]), int.Parse(split[0]));
        }

        /// <summary>
        /// Using julian algorithem logic, calculated number of the days for the given year, month and day.
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <returns></returns>
        public static long GetDays(int year, int month, int day)
        {
            if (month < 3)
            {
                month = month + 12;
                year = year - 1;
            }
            return day + (153 * month - 457) / 5 + 365 * year + (year / 4) - (year / 100) + (year / 400) + 1721119;
        }
    }
}
