﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Cryptography;
using Venkat.Nadendla.DateCalculator.WebAPI.Helper;
using Venkat.Nadendla.DateCalculator.WebAPI.Model;

namespace Venkat.Nadendla.DateCalculator.WebAPI.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    [Consumes("application/json")]
    [ApiController]
    public class DateCalculatorController : ControllerBase
    {        
        /// <summary>
        /// This method will accept the input parameters such as fromDate and endDate and will retrun an json object with number of days
        /// </summary>
        /// <param name="requestDto"></param>
        /// <returns></returns>
        [HttpPost(Name = "CalculateDays")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status200OK)]    
        public async Task<ActionResult> CalculateDays([FromBody] CalculatorInputDto requestDto)
        {
            try {
                await Task.Delay(1000);

                if (requestDto == null || !ModelState.IsValid)
                    return BadRequest();

                if (string.IsNullOrWhiteSpace(requestDto.fromDate))
                {                   
                    return BadRequest();
                }
                if (string.IsNullOrWhiteSpace(requestDto.endDate))
                {
                    return BadRequest();
                }

                CalculatorOutputDto responseDto = new CalculatorOutputDto();
                responseDto.fromDate = requestDto.fromDate;
                responseDto.endDate = requestDto.endDate;


                long noOfDays = DateHelper.GetTotalDays(requestDto.endDate) - DateHelper.GetTotalDays(responseDto.fromDate);
                responseDto.numberOfDays = noOfDays;
                return Ok(responseDto);
            }
            catch(WebException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        
    }
}
