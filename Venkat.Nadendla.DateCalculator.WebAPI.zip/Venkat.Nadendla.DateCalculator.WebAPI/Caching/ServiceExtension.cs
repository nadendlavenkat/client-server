﻿namespace Caching
{
    public class ServiceExtension
    {

    }
}