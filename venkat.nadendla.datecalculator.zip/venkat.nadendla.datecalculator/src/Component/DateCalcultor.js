import React, { useState,useEffect } from "react";
import styles from './DateCalculator.module.css';
function DateCalculator(){

    //declaration of input and output Object
    let calculatorObj = {
        fromDate: '',
        endDate:'',
        numberOfDays:''
    }

    //assinging the object to the useState    
    const[days, setDays] = useState(calculatorObj);  

    //initilizing the error object using useState
    const [errors, setErrors] = useState({
        fromDate:'',
        endDate:'',
        summary:''
    });

    //initilizing the loader    
    const[loading,setLoading]= useState(true);

     // this method when ever we update the endDate field, on valuechange event updating days object using useState
    // also resetting errors object to empty using use state
    const handleFromDateChange = (event) => {
        setDays(prevState => ({
            ...prevState,
            fromDate: event.target.value
        }));
        if(event.target.value){
            setErrors(prevState =>({
                ...prevState,
                fromDate: ''
            }));
        }
    };

    // this method when ever we update the endDate field, on valuechange event updating days object using useState
    // also resetting errors object to empty using use state

    const handleEndDateChange = (event) => {
        setDays(prevState => ({
            ...prevState,
            endDate: event.target.value
        }));
        if(event.target.value){
            setErrors(prevState =>({
                ...prevState,
                endDate: ''
            }));
        }
    };

    //this method is used to get the days between startDate and endDate from the API
    //inputs will be passed as a JSON object and get the response as JSON object along with inputs
    const GetDays = async (e) =>{
        
        e.preventDefault();

        // the below logic is traditional way of handling
        //let startDate = document.getElementById('startDate').value;
        //let endDate = document.getElementById('endDate').value;

        // if(startDate == ""){
        //     alert("Action Required: Please enter Start Date!.");         
        //     e.preventDefault();
        //     return false;
        // }

        // if(endDate == ""){
        //     alert("Action Required: Please enter End Date!.");      
        //     e.preventDefault();   
        //     return false;  
        //}


        // handling errors using useState

         if(!days.fromDate){
            setErrors(prevState =>({
                ...prevState,
                fromDate: 'Start Date is required'
            }))
            //return;
        }
        if(!days.endDate){
            setErrors(prevState =>({
                ...prevState,
                endDate: 'End Date is required'
            }))
            //return;
        }

        if (Object.keys(errors).length > 0) {
            if(!days.fromDate && !days.endDate){                
                return false;
            }
        }

        let isStartDateValid = ValidateDate(days.fromDate);
        let isEndDateValid = ValidateDate(days.endDate);
        let calculatorNewObj = {
            fromDate: days.fromDate,
            endDate:days.endDate
        }
        if(!isStartDateValid){
            setErrors(prevState =>({
                ...prevState,
                summary: 'Invalid Date'
            }))
            //alert("Action Required: Invalid date");
            //e.preventDefault();
        }
        if(!isEndDateValid){
            setErrors(prevState =>({
                ...prevState,
                summary: 'Invalid Date'
            }))
            //alert("Action Required: Invalid date");
            //e.preventDefault();
        }
        if(isStartDateValid && isEndDateValid){
           
            try{

                // calling the web api for the days by passing fromDate and endDate as JSON object
                const requestOptions = {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(calculatorNewObj)
                };

                const response = await fetch('https://localhost:44379/api/DateCalculator/CalculateDays',requestOptions);
                if(!response.ok){
                    throw new Error(response.status);
                }
                const data= await response.json();
                setDays(data);
                setLoading(false);
                setErrors('');
            }
            catch(error){
                //handle the error
                setErrors(error.message);
                setLoading(false);
            }
        }
   }

   // this methhod is used to reset the form fields such as fromDate, endDate and resetting the days object useing useState
   // and also restting the errors object using useState
   const ResetDates = () =>{
        document.getElementById('startDate').value = '';
        document.getElementById('endDate').value = '';
        let calculatornewObj = {
            fromDate: '',
            endDate:'',
            numberOfDays:''
        }
        setDays(calculatornewObj);
        setErrors(prevState =>({
            ...prevState,
            fromDate:'',
            endDate: '',
            summary:''
        }))
   }

   //this method is used to validate the date fields format
    const ValidateDate = (dateString) =>
    {       
        let dateformat = /^(0?[1-9]|[1-2][0-9]|3[01])[\/](0?[1-9]|1[0-2])/;
        var dateParts = [];
        
        dateParts = dateString.split('/');
        
        // Extract day, month, and year components
        var day = parseInt(dateParts[0]);
        var month = parseInt(dateParts[1]);
        var year = parseInt(dateParts[2]);
        
        // Validate year, month, and day ranges
        if (year < 1000 || year > 9999 || month === 0 || month > 12 || day === 0 || day > 31) 
        {            
            return false;
        }
        else if (month === 2) 
        {
            if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
                if(day<=29){                    
                    return true;
                }
                else{                   
                    return false;
                }
            } 
            else
            {
                if(day>28){
                    
                    return false;
                }
                else{                    
                    return true;
                }
            }
        }
        else
        {
            if ([4, 6, 9, 11].includes(month) && day>30) {               
                return false;
            }
            else{               
                return true;
            }
        }
        return true;
    }
   
    // this method is used to restrict the characters and special characters other then forwardslash while inputting the input
     const handleKeyPress = (e) => {
        var key = e.key;       
        const regex =  /[0-9\b\/]/;
        if( !regex.test(key) ) {
            e.preventDefault();
        }
    }


    return (
        <>
            <form className={styles.form}>
                <h2>Calculate the Number of Days Between Dates</h2>             
                <div>
                    <label className={styles.label}>Start Date:</label>
                    <input type="text" maxLength={10} id="startDate" name="startDate"  className={styles.input} placeholder="dd/mm/yyyy" value={days.fromDate} onChange={handleFromDateChange}  onKeyPress={(e) => handleKeyPress(e)}></input>
                    {errors.fromDate && <p className={styles.error} > {errors.fromDate}</p>}
                  
                </div>   
                <div>
                    <label className={styles.label}>End Date:</label>
                    <input type="text" id="endDate"  maxLength={10} name="endDate"  className={styles.input} placeholder="dd/mm/yyyy" value={days.endDate} onChange={handleEndDateChange} onKeyPress={(e) => handleKeyPress(e)}></input>
                    {errors.endDate && <p className={styles.error} > {errors.endDate}</p>}
                   
                </div>
                <div className={styles.label}>                 
                    <label>Number of days:</label>
                    <label>{days.numberOfDays}</label>    
                    {errors.summary && <p className={styles.error} > {errors.summary}</p>}
                </div>
                <div>    
                    <button className={styles.submitButton} onClick={ResetDates}>Reset</button>    
                    {/* <button className="custom-margin-left" onClick={(e) => GetDays(e)}>Calculate No of Days</button>  */}
                    <button type="submit" className={styles.submitButton} style={{marginLeft:5}} onClick={(e) => GetDays(e)}>Calculate No of Days</button>
                </div>           
            </form>
        </>
    )
}

export default DateCalculator;