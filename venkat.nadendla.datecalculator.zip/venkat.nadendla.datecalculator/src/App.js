import logo from './logo.svg';
import './App.css';
import DateCalculator from './Component/DateCalcultor';

function App() {
  return (
    <div className="App">
      <DateCalculator/>
    </div>
  );
}

export default App;
